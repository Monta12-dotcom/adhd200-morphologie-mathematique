import sys
from pathlib import Path
import numpy as np
import pandas as pd
import nibabel as nib
import matplotlib.pyplot as plt
from scipy import ndimage
from skimage.filters import threshold_otsu
from skimage.morphology import ball

root = Path(__file__).resolve().parents[2]
main = pd.read_csv(root / "reports" / "subset_main.csv", dtype={"participant_id": str})
row_number = int(sys.argv[1]) if len(sys.argv) > 1 else 0
row = main.iloc[row_number]
print("site:", row["site"], "| id:", row["participant_id"], "| label:", row["label"], "| age:", row["age"])

img = nib.load(row["path"])
data = img.get_fdata()
voxel = [float(v) for v in img.header.get_zooms()[:3]]   # mm
otsu = threshold_otsu(data)

CLOSE_MM = 3      # radius of the closing ball, in mm
CAP_MM = 80       # height of the cranium cap below the vertex, in mm


def make_mask(data, threshold):
    mask = data > threshold
    # keep the largest connected component
    labels, n = ndimage.label(mask)
    sizes = ndimage.sum(mask, labels, range(1, n + 1))
    mask = labels == (np.argmax(sizes) + 1)
    # closing with a ball (pad first, so the border does not create artifacts)
    r = int(round(CLOSE_MM / min(voxel)))
    mask = np.pad(mask, r + 1)
    mask = ndimage.binary_closing(mask, structure=ball(r))
    mask = mask[r + 1:-(r + 1), r + 1:-(r + 1), r + 1:-(r + 1)]
    # fill holes slice by slice along the axial axis
    for k in range(mask.shape[2]):
        mask[:, :, k] = ndimage.binary_fill_holes(mask[:, :, k])
    return mask


def measure(mask):
    xs, ys, zs = np.where(mask)
    top = zs.max()                                  # vertex (z grows toward the top)
    bottom = top - int(round(CAP_MM / voxel[2])) + 1
    cap = mask[:, :, bottom:top + 1]
    cap_volume = cap.sum() * np.prod(voxel) / 1000  # mL
    width = 0
    length = 0
    area = 0
    for k in range(cap.shape[2]):
        sl = cap[:, :, k]
        if sl.any():
            xi = np.where(sl.any(axis=1))[0]
            yi = np.where(sl.any(axis=0))[0]
            width = max(width, (xi.max() - xi.min() + 1) * voxel[0])
            length = max(length, (yi.max() - yi.min() + 1) * voxel[1])
            area = max(area, sl.sum() * voxel[0] * voxel[1] / 100)   # cm2
    return top, bottom, cap_volume, width, length, area


factors = [1.0, 0.6, 0.4]
fig, axes = plt.subplots(3, 3, figsize=(12, 12))
for i, f in enumerate(factors):
    mask = make_mask(data, otsu * f)
    top, bottom, cap_volume, width, length, area = measure(mask)
    print("threshold x" + str(f) + " (" + str(round(float(otsu * f))) + "): cap volume",
          round(float(cap_volume)), "mL | width", round(float(width)), "mm | length",
          round(float(length)), "mm | max axial area", round(float(area), 1), "cm2")
    xs, ys, zs = np.where(mask)
    cx, cy, cz = int(xs.mean()), int(ys.mean()), int(top - 40 / voxel[2])
    views = [data[cx, :, :], data[:, cy, :], data[:, :, cz]]
    outlines = [mask[cx, :, :], mask[:, cy, :], mask[:, :, cz]]
    for j in range(3):
        ax = axes[i, j]
        ax.imshow(views[j].T, cmap="gray", origin="lower")
        ax.contour(outlines[j].T, levels=[0.5], colors="red", linewidths=0.8)
        if j < 2:
            ax.axhline(bottom, color="cyan", linewidth=0.8)   # bottom of the cap
        ax.set_title("threshold x" + str(f), fontsize=9)
        ax.axis("off")

out = root / "reports" / ("head_check2_" + row["site"] + "_" + row["participant_id"] + ".png")
fig.savefig(out, dpi=110, bbox_inches="tight")
print("figure saved:", out)