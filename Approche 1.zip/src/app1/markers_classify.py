import re
from pathlib import Path
import numpy as np
import pandas as pd

root = Path(__file__).resolve().parents[2]
rng = np.random.default_rng(0)

# ---------- 1. load and clean (same rules as markers_check.py) ----------
t = pd.read_csv(root / "reports" / "markers_head.csv", dtype={"participant_id": str})
main = pd.read_csv(root / "reports" / "subset_main.csv", dtype={"participant_id": str})
main["row"] = range(len(main))
shape = main["shape"].apply(lambda s: [int(v) for v in re.findall(r"\d+", str(s))])
main["fov_x_mm"] = shape.str[0] * main["vox_x"]
main["fov_y_mm"] = shape.str[1] * main["vox_y"]
t = t.merge(main[["row", "fov_x_mm", "fov_y_mm"]], on="row")

cut = (t["cap_width_mm"] >= t["fov_x_mm"] - 3) | (t["cap_length_mm"] >= t["fov_y_mm"] - 3)
t = t[~cut]
EXCLUDE_ROWS = [339]                      # thin scan, excluded by hand
t = t[~t["row"].isin(EXCLUDE_ROWS)]
t = t.dropna(subset=["gender", "age"]).reset_index(drop=True)

t["shape_ratio"] = t["cap_width_mm"] / t["cap_length_mm"]
t["y"] = (t["label"] == "ADHD").astype(int)
MARKERS = ["cap_area_cm2", "shape_ratio", "sharpness"]
print("children used:", len(t), "| ADHD:", int(t["y"].sum()), "| TD:", int((1 - t["y"]).sum()))


# ---------- 2. remove site (and optionally sex and age) from the markers ----------
def adjust(df, remove):
    z = pd.DataFrame(index=df.index)
    for m in MARKERS:
        z[m] = df.groupby("site")[m].transform(lambda v: (v - v.mean()) / v.std())
    z = z.to_numpy()
    if remove == "site":
        return z
    # "full": also remove the linear effect of sex and age (no labels used)
    X = np.column_stack([np.ones(len(df)), (df["gender"] == "Male").astype(float), df["age"].astype(float)])
    out = np.zeros_like(z)
    for j in range(z.shape[1]):
        beta = np.linalg.lstsq(X, z[:, j], rcond=None)[0]
        resid = z[:, j] - X @ beta
        out[:, j] = resid / resid.std()
    return out


# ---------- 3. the classifier: one threshold per marker, weighted vote ----------
def fit_stumps(X, y):
    # for each marker, find the threshold + direction with the best Youden J on the TRAINING data
    n = X.shape[1]
    thr = np.zeros(n)
    sign = np.ones(n)
    weight = np.zeros(n)
    for j in range(n):
        x = X[:, j]
        best = -1.0
        for c in np.quantile(x, np.linspace(0.05, 0.95, 91)):
            for s in (1, -1):
                votes_adhd = (s * (x - c)) > 0
                tpr = votes_adhd[y == 1].mean()
                tnr = (~votes_adhd[y == 0]).mean()
                J = tpr + tnr - 1
                if J > best:
                    best, thr[j], sign[j] = J, c, s
        weight[j] = max(best, 0)
    return thr, sign, weight


def score(X, thr, sign, weight):
    votes = np.where(sign * (X - thr) > 0, 1, -1)      # +1 = votes ADHD, -1 = votes TD
    return votes @ weight


def balanced_accuracy(y, pred):
    tpr = pred[y == 1].mean()
    tnr = (~pred[y == 0]).mean()
    return 0.5 * (tpr + tnr)


def auc(y, s):
    pos = s[y == 1]
    neg = s[y == 0]
    return (pos[:, None] > neg[None, :]).mean() + 0.5 * (pos[:, None] == neg[None, :]).mean()


# ---------- 4. cross-validation, stratified by site and label ----------
def make_folds(strata, n_splits):
    fold = np.zeros(len(strata), dtype=int)
    for s in np.unique(strata):
        idx = np.where(strata == s)[0]
        rng.shuffle(idx)
        fold[idx] = (np.arange(len(idx)) + rng.integers(n_splits)) % n_splits
    return fold


def cross_validate(X, y, sites, use, repeats):
    strata = np.array([a + "_" + str(b) for a, b in zip(sites, y)])
    ba, au = [], []
    per_site = {s: [] for s in np.unique(sites)}
    for r in range(repeats):
        fold = make_folds(strata, 5)
        sc = np.zeros(len(y))
        for k in range(5):
            train = fold != k
            test = fold == k
            thr, sign, weight = fit_stumps(X[train][:, use], y[train])
            sc[test] = score(X[test][:, use], thr, sign, weight)
        pred = sc > 0
        ba.append(balanced_accuracy(y, pred))
        au.append(auc(y, sc))
        for s in per_site:
            m = sites == s
            per_site[s].append(balanced_accuracy(y[m], pred[m]))
    return np.mean(ba), np.mean(au), {s: float(np.mean(v)) for s, v in per_site.items()}


def permute_within_site(y, sites):
    y2 = y.copy()
    for s in np.unique(sites):
        idx = np.where(sites == s)[0]
        y2[idx] = rng.permutation(y[idx])
    return y2


# ---------- 5. run ----------
y = t["y"].to_numpy()
sites = t["site"].to_numpy()
N_PERM = 200

for remove in ["site", "full"]:
    X = adjust(t, remove)
    title = "site corrected only" if remove == "site" else "site + sex + age removed"
    print("\n=== " + title + " ===")
    for j, m in enumerate(MARKERS):
        ba, au, _ = cross_validate(X, y, sites, [j], 10)
        print("  alone:", m.ljust(14), "balanced acc", round(ba, 3), "| AUC", round(au, 3))
    all_use = list(range(len(MARKERS)))
    ba, au, per_site = cross_validate(X, y, sites, all_use, 10)
    print("  all three:".ljust(23), "balanced acc", round(ba, 3), "| AUC", round(au, 3))

    # permutation baseline: shuffle labels inside each site
    perm = []
    for p in range(N_PERM):
        perm.append(cross_validate(X, permute_within_site(y, sites), sites, all_use, 1)[0])
    perm = np.array(perm)
    pval = (1 + (perm >= ba).sum()) / (N_PERM + 1)
    print("  shuffled labels: mean", round(perm.mean(), 3), "| 95th percentile", round(np.percentile(perm, 95), 3),
          "| p-value", round(pval, 3))
    print("  balanced accuracy by site:", {s: round(v, 2) for s, v in per_site.items()})

# thresholds learned on all children, for illustration only (not an evaluation)
X = adjust(t, "site")
thr, sign, weight = fit_stumps(X, y)
print("\nthresholds fitted on ALL children (site z-scores), illustration only:")
for j, m in enumerate(MARKERS):
    direction = "ADHD if above" if sign[j] > 0 else "ADHD if below"
    print(" ", m.ljust(14), direction, round(thr[j], 2), "| weight (J)", round(weight[j], 3))