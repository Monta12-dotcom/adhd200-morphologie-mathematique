import sys
from pathlib import Path
import numpy as np
import pandas as pd
import nibabel as nib
import matplotlib.pyplot as plt
from scipy import ndimage
from skimage.filters import threshold_otsu

root = Path(__file__).resolve().parents[2]
main = pd.read_csv(root / "reports" / "subset_main.csv", dtype={"participant_id": str})

# which child? default = first row, or give a row number: python head_one_scan.py 40
row_number = int(sys.argv[1]) if len(sys.argv) > 1 else 0
row = main.iloc[row_number]
print("site:", row["site"], "| id:", row["participant_id"], "| label:", row["label"], "| age:", row["age"])

img = nib.load(row["path"])
data = img.get_fdata()
voxel = img.header.get_zooms()[:3]          # voxel size in mm
print("shape:", data.shape, "| voxel (mm):", voxel)

# 1. threshold
t = threshold_otsu(data)
mask = data > t
print("Otsu threshold:", round(float(t), 1))

# 2. keep the largest connected component
labels, n = ndimage.label(mask)
sizes = ndimage.sum(mask, labels, range(1, n + 1))
mask = labels == (np.argmax(sizes) + 1)

# 3. fill holes slice by slice (axial = third axis)
for k in range(mask.shape[2]):
    mask[:, :, k] = ndimage.binary_fill_holes(mask[:, :, k])

# 4. measures in millimetres
volume_ml = mask.sum() * np.prod(voxel) / 1000
xs, ys, zs = np.where(mask)
width = (xs.max() - xs.min() + 1) * voxel[0]
length = (ys.max() - ys.min() + 1) * voxel[1]
height = (zs.max() - zs.min() + 1) * voxel[2]
print("head volume (mL):", round(float(volume_ml), 1))
print("extent x/y/z (mm):", round(float(width)), round(float(length)), round(float(height)))

# picture: three middle slices with the mask outline in red
cx, cy, cz = int(xs.mean()), int(ys.mean()), int(zs.mean())
views = [data[cx, :, :], data[:, cy, :], data[:, :, cz]]
outlines = [mask[cx, :, :], mask[:, cy, :], mask[:, :, cz]]
fig, axes = plt.subplots(1, 3, figsize=(12, 4))
for ax, im, m in zip(axes, views, outlines):
    ax.imshow(im.T, cmap="gray", origin="lower")
    ax.contour(m.T, levels=[0.5], colors="red", linewidths=0.8)
    ax.axis("off")
out = root / "reports" / ("head_check_" + row["site"] + "_" + row["participant_id"] + ".png")
fig.savefig(out, dpi=120, bbox_inches="tight")
print("figure saved:", out)