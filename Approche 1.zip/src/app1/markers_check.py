import re
from pathlib import Path
import pandas as pd
from scipy.stats import spearmanr

root = Path(__file__).resolve().parents[2]
t = pd.read_csv(root / "reports" / "markers_head.csv", dtype={"participant_id": str})
main = pd.read_csv(root / "reports" / "subset_main.csv", dtype={"participant_id": str})

# field of view in mm for every scan (image size x voxel size)
main["row"] = range(len(main))
shape = main["shape"].apply(lambda s: [int(v) for v in re.findall(r"\d+", str(s))])
main["fov_x_mm"] = shape.str[0] * main["vox_x"]
main["fov_y_mm"] = shape.str[1] * main["vox_y"]
t = t.merge(main[["row", "fov_x_mm", "fov_y_mm"]], on="row")

# a head that fills the whole field of view was cut off by the scan
cut = (t["cap_width_mm"] >= t["fov_x_mm"] - 3) | (t["cap_length_mm"] >= t["fov_y_mm"] - 3)
print("scans excluded because the head fills the field of view:", int(cut.sum()))
print(t.loc[cut, ["row", "site", "participant_id", "label", "cap_width_mm", "fov_x_mm", "cap_length_mm", "fov_y_mm"]])
t = t[~cut].copy()

markers = ["cap_volume_ml", "cap_width_mm", "cap_length_mm", "cap_area_cm2", "sharpness", "noise"]
zcols = [m + "_z" for m in markers]

# z-score each marker inside its site
for m in markers:
    t[m + "_z"] = t.groupby("site")[m].transform(lambda v: (v - v.mean()) / v.std())

print("\nchildren:", len(t))

print("\ncorrelation with age (Spearman rho, p)")
for m in markers:
    rho, p = spearmanr(t[m + "_z"], t["age"])
    print(" ", m, round(rho, 2), round(p, 4))

print("\nmale minus female, in standard deviations")
for m in markers:
    male = t.loc[t["gender"] == "Male", m + "_z"].mean()
    female = t.loc[t["gender"] == "Female", m + "_z"].mean()
    print(" ", m, round(male - female, 2))

print("\ncorrelation between markers")
print(t[zcols].corr().round(2))

print("\nmean z-score by site and label")
print(t.groupby(["site", "label"])[zcols].mean().round(2))