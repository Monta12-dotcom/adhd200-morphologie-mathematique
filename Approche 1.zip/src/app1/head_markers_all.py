import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import nibabel as nib
import matplotlib.pyplot as plt
from scipy import ndimage
from skimage.filters import threshold_otsu
from skimage.morphology import ball

root = Path(__file__).resolve().parents[2]
main = pd.read_csv(root / "reports" / "subset_main.csv", dtype={"participant_id": str})
limit = int(sys.argv[1]) if len(sys.argv) > 1 else len(main)   # python script.py 10 = test on 10 scans

FACTOR = 0.6       # threshold = 0.6 x Otsu
CLOSE_MM = 3       # closing ball radius (mm)
CAP_MM = 80        # cranium cap height below the vertex (mm)
MARGIN_MM = 10     # extra slices kept below the cap, to avoid cut-edge effects

# 2 random scans per site, kept as thumbnails for the visual check
thumb_rows = set(main.groupby("site").sample(2, random_state=0).index)


def measure_scan(path, want_thumb):
    img = nib.load(path)
    data = np.asarray(img.dataobj, dtype=np.float32)
    voxel = [float(v) for v in img.header.get_zooms()[:3]]
    otsu = float(threshold_otsu(data))
    thr = otsu * FACTOR

    # largest connected component of the thresholded image
    mask = data > thr
    labels, n = ndimage.label(mask)
    sizes = np.bincount(labels.ravel())
    sizes[0] = 0
    mask = labels == sizes.argmax()

    # crop to the top of the head (cap + margin), then to the bounding box
    zs = np.where(mask.any(axis=(0, 1)))[0]
    top = int(zs.max())
    cap_vox = int(round(CAP_MM / voxel[2]))
    margin_vox = int(round(MARGIN_MM / voxel[2]))
    z0 = max(0, top - cap_vox - margin_vox)
    slab = data[:, :, z0:top + 1]
    mask = mask[:, :, z0:top + 1]
    # background noise from the left/right margins of the slab
    background = np.concatenate([slab[:15].ravel(), slab[-15:].ravel()])
    xs = np.where(mask.any(axis=(1, 2)))[0]
    ys = np.where(mask.any(axis=(0, 2)))[0]
    mask = mask[xs.min():xs.max() + 1, ys.min():ys.max() + 1, :]
    sub = slab[xs.min():xs.max() + 1, ys.min():ys.max() + 1, :]

    # closing with a ball (pad first), then fill holes slice by slice
    r = int(round(CLOSE_MM / min(voxel)))
    mask = np.pad(mask, r + 1)
    mask = ndimage.binary_closing(mask, structure=ball(r))
    mask = mask[r + 1:-(r + 1), r + 1:-(r + 1), r + 1:-(r + 1)]
    for k in range(mask.shape[2]):
        mask[:, :, k] = ndimage.binary_fill_holes(mask[:, :, k])

    # the cap = the last cap_vox slices
    n_cap = min(cap_vox, mask.shape[2])
    cap_mask = mask[:, :, -n_cap:]
    cap_data = sub[:, :, -n_cap:]

    cap_volume = cap_mask.sum() * np.prod(voxel) / 1000          # mL
    width = 0
    length = 0
    area = 0
    for k in range(n_cap):
        sl = cap_mask[:, :, k]
        if sl.any():
            xi = np.where(sl.any(axis=1))[0]
            yi = np.where(sl.any(axis=0))[0]
            width = max(width, (xi.max() - xi.min() + 1) * voxel[0])
            length = max(length, (yi.max() - yi.min() + 1) * voxel[1])
            area = max(area, sl.sum() * voxel[0] * voxel[1] / 100)   # cm2

    # quality markers: sharpness (morphological gradient) and background noise
    median_intensity = float(np.median(cap_data[cap_mask]))
    gradient = ndimage.grey_dilation(cap_data, size=3) - ndimage.grey_erosion(cap_data, size=3)
    inner = ndimage.binary_erosion(cap_mask, iterations=3)
    sharpness = float(gradient[inner].mean() / median_intensity)
    noise = float(background.std() / median_intensity)

    out = {"cap_volume_ml": float(cap_volume), "cap_width_mm": float(width),
           "cap_length_mm": float(length), "cap_area_cm2": float(area),
           "sharpness": sharpness, "noise": noise, "otsu": otsu,
           "flag_vertex_cut": top >= data.shape[2] - 1,         # head touches the top of the volume
           "flag_cap_incomplete": top - cap_vox + 1 < 0}

    thumb = None
    if want_thumb:
        mx = mask.shape[0] // 2
        cz = mask.shape[2] - n_cap // 2
        thumb = {"sag": sub[mx, :, :], "sag_m": mask[mx, :, :],
                 "axi": sub[:, :, cz], "axi_m": mask[:, :, cz]}
    return out, thumb


rows = []
thumbs = []
start = time.time()
for i in range(limit):
    r = main.iloc[i]
    try:
        out, thumb = measure_scan(r["path"], i in thumb_rows)
    except Exception as e:
        print("[error]", r["site"], r["participant_id"], e)
        continue
    out.update({"row": i, "site": r["site"], "participant_id": r["participant_id"],
                "label": r["label"], "age": r["age"], "gender": r["gender"]})
    rows.append(out)
    if thumb is not None:
        thumbs.append((r["site"] + " " + r["participant_id"] + " " + r["label"], thumb))
    if i == 0 or (i + 1) % 10 == 0:
        per_scan = (time.time() - start) / (i + 1)
        print("done", i + 1, "of", limit, "| seconds per scan:", round(per_scan, 1),
              "| time left (min):", round(per_scan * (limit - i - 1) / 60, 1))

table = pd.DataFrame(rows)
table.to_csv(root / "reports" / "markers_head.csv", index=False)
print("\nsaved", len(table), "scans to reports\\markers_head.csv")

# automatic checks
print("\nhead touches top of volume:", int(table["flag_vertex_cut"].sum()),
      "| cap incomplete:", int(table["flag_cap_incomplete"].sum()))
z = table.groupby("site")["cap_volume_ml"].transform(lambda v: (v - v.mean()) / v.std())
outliers = table[z.abs() > 3]
print("cap volume outliers (|z| > 3 within site):")
print(outliers[["row", "site", "participant_id", "label", "age", "cap_volume_ml"]])
print("\nmean of each marker by label")
print(table.groupby("label")[["cap_volume_ml", "cap_width_mm", "cap_length_mm",
                              "cap_area_cm2", "sharpness", "noise"]].mean().round(3))

# montage for the visual check
if len(thumbs) > 0:
    nrows = (len(thumbs) + 1) // 2
    fig, axes = plt.subplots(nrows, 4, figsize=(12, 3 * nrows), squeeze=False)
    for ax in axes.ravel():
        ax.axis("off")
    for idx, (title, t) in enumerate(thumbs):
        row_i = idx // 2
        col = (idx % 2) * 2
        axes[row_i, col].imshow(t["sag"].T, cmap="gray", origin="lower")
        axes[row_i, col].contour(t["sag_m"].T, levels=[0.5], colors="red", linewidths=0.7)
        axes[row_i, col].set_title(title, fontsize=7)
        axes[row_i, col + 1].imshow(t["axi"].T, cmap="gray", origin="lower")
        axes[row_i, col + 1].contour(t["axi_m"].T, levels=[0.5], colors="red", linewidths=0.7)
    fig.savefig(root / "reports" / "head_qc_montage.png", dpi=110, bbox_inches="tight")
    print("montage saved: reports\\head_qc_montage.png")