"""Lab 01: course morphology operators on a real 3D T1w scan.
Head mask from thresholding: NOT a cortical segmentation."""
from pathlib import Path
import numpy as np
import nibabel as nib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu

ROOT = Path(__file__).resolve().parents[2]
SCAN = ROOT / "ADHD200_BIDS/Brown/sub-0026001/ses-1/anat/sub-0026001_ses-1_run-1_T1w.nii.gz"
OUT = ROOT / "reports" / "lab01"
OUT.mkdir(parents=True, exist_ok=True)

# ---- 1. load and inspect -------------------------------------------------
img = nib.load(SCAN)
data = img.get_fdata(dtype=np.float32)
vox = img.header.get_zooms()[:3]
print("shape:", data.shape, "| voxel (mm):", vox, "| orientation:", nib.aff2axcodes(img.affine))
print("intensity min/mean/max:", data.min(), round(float(data.mean()), 1), data.max())
vox_mm3 = float(np.prod(vox))

cx, cy, cz = (s // 2 for s in data.shape)
fig, ax = plt.subplots(1, 4, figsize=(18, 4.5))
ax[0].imshow(np.rot90(data[cx, :, :]), cmap="gray"); ax[0].set_title("sagittal (x fixed)")
ax[1].imshow(np.rot90(data[:, cy, :]), cmap="gray"); ax[1].set_title("coronal (y fixed)")
ax[2].imshow(np.rot90(data[:, :, cz]), cmap="gray"); ax[2].set_title("axial (z fixed)")
ax[3].hist(data.ravel(), bins=200, log=True); ax[3].set_title("histogram (log y)")
fig.savefig(OUT / "01_slices_histogram.png", dpi=110, bbox_inches="tight"); plt.close(fig)

# ---- 2. binary mask: threshold + largest connected component -----------------
t = threshold_otsu(data)
mask = data > t
lab, n = ndi.label(mask)                       # default connectivity = 6-neighbours
sizes = ndi.sum(mask, lab, range(1, n + 1))
X = lab == (1 + int(np.argmax(sizes)))
print(f"\nOtsu threshold: {t:.1f} | components: {n} | kept largest: {int(X.sum())} voxels "
      f"= {X.sum() * vox_mm3 / 1000:.0f} mL")

# ---- 3. structuring elements (voxel units) ------------------------------
def ball(r):
    g = np.arange(-r, r + 1)
    zz, yy, xx = np.meshgrid(g, g, g, indexing="ij")
    return (xx**2 + yy**2 + zz**2) <= r * r

B_ball, B_cube = ball(2), np.ones((3, 3, 3), bool)
print("SE sizes (voxels): ball r=2 ->", int(B_ball.sum()), "| cube 3x3x3 ->", int(B_cube.sum()))

def ncomp(m): return ndi.label(m)[1]
def eros(m, b): return ndi.binary_erosion(m, structure=b)
def dil(m, b): return ndi.binary_dilation(m, structure=b)
def opening(m, b): return dil(eros(m, b), b)
def closing(m, b): return eros(dil(m, b), b)

# ---- 4. apply and measure ---------------------------------------------------
res = {"original": X,
       "erosion (ball)": eros(X, B_ball), "dilation (ball)": dil(X, B_ball),
       "opening (ball)": opening(X, B_ball), "closing (ball)": closing(X, B_ball),
       "erosion (cube)": eros(X, B_cube)}
print("\n%-18s %10s %10s %6s" % ("result", "voxels", "mL", "comps"))
for k, m in res.items():
    print("%-18s %10d %10.0f %6d" % (k, m.sum(), m.sum() * vox_mm3 / 1000, ncomp(m)))

# ---- 5. verify course properties --------------------------------------------
op, cl = res["opening (ball)"], res["closing (ball)"]
print("\nProperty checks (True = property holds on this image):")
print("opening anti-extensive  (opening ⊆ X):", bool(np.all(op <= X)))
print("closing extensive       (X ⊆ closing):", bool(np.all(X <= cl)))
print("opening idempotent      :", bool(np.array_equal(opening(op, B_ball), op)))
print("closing idempotent      :", bool(np.array_equal(closing(cl, B_ball), cl)))
print("erosion ⊆ X ⊆ dilation  :", bool(np.all(res["erosion (ball)"] <= X) and np.all(X <= res["dilation (ball)"])))

# ---- 6. figure: same axial slice for every result ---------------------------
fig, ax = plt.subplots(2, 3, figsize=(14, 9))
for a, (k, m) in zip(ax.ravel(), res.items()):
    a.imshow(np.rot90(m[:, :, cz]), cmap="gray"); a.set_title(k); a.axis("off")
fig.savefig(OUT / "02_morphology_axial.png", dpi=110, bbox_inches="tight"); plt.close(fig)
print("\nFigures saved in", OUT)