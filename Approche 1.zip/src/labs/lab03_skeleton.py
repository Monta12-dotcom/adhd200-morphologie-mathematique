from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.morphology import skeletonize

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "reports" / "lab03"
OUT.mkdir(parents=True, exist_ok=True)

# =============== PART A: hit-or-miss (slides 45-46) ===============
# Detect the right end of a horizontal line.
# Bi = pixels that must be object, Be = pixels that must be background.
X = np.zeros((9, 12), dtype=bool)
X[4, 2:9] = True                      # a horizontal line of 7 pixels
X[1:3, 9:11] = True                   # a small block, for contrast

Bi = np.array([[0, 0, 0],
               [1, 1, 0],
               [0, 0, 0]], dtype=bool)   # centre and left neighbour are object
Be = np.array([[1, 1, 1],
               [0, 0, 1],
               [1, 1, 1]], dtype=bool)   # right side must be background

hit = ndi.binary_erosion(X, structure=Bi, border_value=0)
miss = ndi.binary_erosion(~X, structure=Be, border_value=1)
hom = hit & miss                          # X (x) B
print("=== PART A: hit-or-miss ===")
print("pixels found:", list(zip(*np.nonzero(hom))))
print("expected    : [(4, 8)]  (right end of the line)")

# =============== PART B: thinning (slide 47) ===============
# X thin B = X - (X (x) B). Removing the end pixel shortens the line by one.
thin1 = X & ~hom
print("\n=== PART B: thinning ===")
print("line length before:", int(X[4].sum()), "| after one thinning step:", int(thin1[4].sum()))

# =============== PART C: 3D skeleton on a known shape ===============
# Synthetic "tree": a vertical trunk with two branches, thickened into tubes.
shape = (60, 60, 60)
centre = np.zeros(shape, dtype=bool)
centre[10:40, 30, 30] = True              # trunk along axis 0
centre[40, 30, 30:50] = True              # branch to the +axis 2 side
centre[40, 30, 10:30] = True              # branch to the -axis 2 side
centre[40:55, 30, 10] = True              # extra tip going up from the left branch
centre[40:55, 30, 49] = True              # extra tip going up from the right branch

dist = ndi.distance_transform_edt(~centre)
tube = dist <= 3                          # tube of radius 3 voxels
print("\n=== PART C: 3D skeleton ===")
print("tube voxels:", int(tube.sum()))

skel = skeletonize(tube)                  # 3D thinning
print("skeleton voxels:", int(skel.sum()))

# Count neighbours of each skeleton voxel (26-connectivity)
kernel = np.ones((3, 3, 3), dtype=int)
kernel[1, 1, 1] = 0
neighbours = ndi.convolve(skel.astype(int), kernel, mode="constant") * skel
endpoints = skel & (neighbours == 1)
branchpoints = skel & (neighbours >= 3)
print("end points (1 neighbour)      :", int(endpoints.sum()))
print("branch-point voxels (>=3 nbrs):", int(branchpoints.sum()))

# Connected components of the skeleton (26-connectivity)
_, n_comp = ndi.label(skel, structure=np.ones((3, 3, 3)))
print("skeleton components           :", n_comp)

# Length: count voxels (rough, ignores diagonal steps)
print("approximate length (voxels)   :", int(skel.sum()))
print("true centreline length (voxels):", int(centre.sum()))

# Figure: project everything onto one plane
fig, ax = plt.subplots(1, 2, figsize=(10, 5))
ax[0].imshow(tube.max(axis=1), cmap="gray"); ax[0].set_title("tube (projection)")
ax[1].imshow(tube.max(axis=1), cmap="gray", alpha=0.4)
ax[1].imshow(np.ma.masked_where(~skel.max(axis=1), skel.max(axis=1)), cmap="autumn")
ey, ex = np.nonzero(endpoints.max(axis=1))
ax[1].scatter(ex, ey, c="cyan", s=30, label="end points")
by, bx = np.nonzero(branchpoints.max(axis=1))
ax[1].scatter(bx, by, c="lime", s=30, label="branch points")
ax[1].legend(); ax[1].set_title("skeleton")
fig.savefig(OUT / "01_skeleton.png", dpi=100, bbox_inches="tight")
plt.close(fig)
print("\nFigure saved in", OUT)