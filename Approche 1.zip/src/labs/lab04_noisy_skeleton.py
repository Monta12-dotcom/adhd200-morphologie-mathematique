from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.morphology import skeletonize

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "reports" / "lab04"
OUT.mkdir(parents=True, exist_ok=True)
rng = np.random.default_rng(0)          # fixed seed: same result every run


def ball(r):
    g = np.arange(-r, r + 1)
    z, y, x = np.meshgrid(g, g, g, indexing="ij")
    return (x**2 + y**2 + z**2) <= r * r


def clean(mask, r):
    """Closing then opening, with padding to avoid border effects."""
    p = r + 1
    b = ball(r)
    m = np.pad(mask, p)
    m = ndi.binary_erosion(ndi.binary_dilation(m, structure=b), structure=b)   # closing
    m = ndi.binary_dilation(ndi.binary_erosion(m, structure=b), structure=b)   # opening
    return m[p:-p, p:-p, p:-p]


def analyse(mask):
    skel = skeletonize(mask)
    kernel = np.ones((3, 3, 3), dtype=int)
    kernel[1, 1, 1] = 0
    nb = ndi.convolve(skel.astype(int), kernel, mode="constant") * skel
    ends = int((skel & (nb == 1)).sum())
    junctions = ndi.label(skel & (nb >= 3), structure=np.ones((3, 3, 3)))[1]  # clusters, not voxels
    return skel, ends, junctions


# ----- the same T-shaped tube as Lab 03 -----
centre = np.zeros((60, 60, 60), dtype=bool)
centre[10:40, 30, 30] = True
centre[40, 30, 10:50] = True
centre[40:55, 30, 10] = True
centre[40:55, 30, 49] = True
tube = ndi.distance_transform_edt(~centre) <= 3

# ----- add noise: flip 2% of the voxels on the surface layer -----
surface = tube & ~ndi.binary_erosion(tube)             # outer layer of the tube
near = ndi.binary_dilation(tube) & ~tube               # layer just outside
border_zone = surface | near
flip = border_zone & (rng.random(tube.shape) < 0.02)
noisy = tube ^ flip                                    # XOR flips the chosen voxels
print("voxels flipped:", int(flip.sum()), "of", int(border_zone.sum()), "border-zone voxels")

# ----- compare -----
print("\n%-22s %8s %8s %10s" % ("case", "voxels", "ends", "junctions"))
results = {}
for name, m in [("clean tube", tube), ("noisy tube", noisy),
                ("noisy, cleaned r=1", clean(noisy, 1)),
                ("noisy, cleaned r=2", clean(noisy, 2)),
                ("noisy, cleaned r=3", clean(noisy, 3))]:
    skel, e, j = analyse(m)
    results[name] = (m, skel, e, j)
    print("%-22s %8d %8d %10d" % (name, m.sum(), e, j))
print("\ntrue topology: 3 ends, 1 junction")

fig, ax = plt.subplots(1, 4, figsize=(20, 5))
for a, name in zip(ax, ["clean tube", "noisy tube", "noisy, cleaned r=1", "noisy, cleaned r=2"]):
    m, skel, e, j = results[name]
    a.imshow(m.max(axis=1), cmap="gray", alpha=0.5)
    a.imshow(np.ma.masked_where(~skel.max(axis=1), skel.max(axis=1)), cmap="autumn")
    a.set_title("%s\nends=%d junctions=%d" % (name, e, j))
fig.savefig(OUT / "01_noisy_skeleton.png", dpi=100, bbox_inches="tight")
plt.close(fig)
print("Figure saved in", OUT)