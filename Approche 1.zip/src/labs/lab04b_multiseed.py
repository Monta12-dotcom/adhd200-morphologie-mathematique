from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.morphology import skeletonize

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "reports" / "lab04b"
OUT.mkdir(parents=True, exist_ok=True)

N_SEEDS = 30
NOISE_LEVELS = [0.02, 0.06]
RADII = [1, 2, 3]


def ball(r):
    g = np.arange(-r, r + 1)
    z, y, x = np.meshgrid(g, g, g, indexing="ij")
    return (x**2 + y**2 + z**2) <= r * r


def clean(mask, r):
    p = r + 1
    b = ball(r)
    m = np.pad(mask, p)
    m = ndi.binary_erosion(ndi.binary_dilation(m, structure=b), structure=b)  # closing
    m = ndi.binary_dilation(ndi.binary_erosion(m, structure=b), structure=b)  # opening
    return m[p:-p, p:-p, p:-p]


def analyse(mask):
    skel = skeletonize(mask)
    kernel = np.ones((3, 3, 3), dtype=int)
    kernel[1, 1, 1] = 0
    nb = ndi.convolve(skel.astype(int), kernel, mode="constant") * skel
    ends = int((skel & (nb == 1)).sum())
    junctions = ndi.label(skel & (nb >= 3), structure=np.ones((3, 3, 3)))[1]
    return ends, junctions


# the same T-shaped tube as Labs 03 and 04
centre = np.zeros((60, 60, 60), dtype=bool)
centre[10:40, 30, 30] = True
centre[40, 30, 10:50] = True
centre[40:55, 30, 10] = True
centre[40:55, 30, 49] = True
tube = ndi.distance_transform_edt(~centre) <= 3

surface = tube & ~ndi.binary_erosion(tube)
near = ndi.binary_dilation(tube) & ~tube
border_zone = surface | near

# damage of cleaning the CLEAN tube (no noise): shows the cost of the operator itself
print("Cost of cleaning the clean tube (voxels that differ from the original):")
for r in RADII:
    print("  r=%d -> %d voxels differ" % (r, int((clean(tube, r) ^ tube).sum())))

cases = ["noisy"] + ["cleaned r=%d" % r for r in RADII]
success_table = {}

for level in NOISE_LEVELS:
    ok = {c: 0 for c in cases}
    ends_all = {c: [] for c in cases}
    diff_all = {c: [] for c in cases}
    for seed in range(N_SEEDS):
        rng = np.random.default_rng(seed)
        flip = border_zone & (rng.random(tube.shape) < level)
        noisy = tube ^ flip
        masks = {"noisy": noisy}
        for r in RADII:
            masks["cleaned r=%d" % r] = clean(noisy, r)
        for name, m in masks.items():
            e, j = analyse(m)
            ends_all[name].append(e)
            diff_all[name].append(int((m ^ tube).sum()))
            if e == 3 and j == 1:
                ok[name] += 1
    success_table[level] = ok
    print("\n=== noise level %.0f%% (%d seeds) ===" % (level * 100, N_SEEDS))
    print("%-14s %10s %12s %16s" % ("case", "correct", "mean ends", "mean voxels differ"))
    for c in cases:
        print("%-14s %7d/%d %12.2f %16.0f" % (c, ok[c], N_SEEDS,
                                              np.mean(ends_all[c]), np.mean(diff_all[c])))

# figure: success rate per case and noise level
fig, ax = plt.subplots(figsize=(8, 4.5))
width = 0.35
for i, level in enumerate(NOISE_LEVELS):
    vals = [success_table[level][c] / N_SEEDS for c in cases]
    ax.bar(np.arange(len(cases)) + i * width, vals, width, label="noise %.0f%%" % (level * 100))
ax.set_xticks(np.arange(len(cases)) + width / 2)
ax.set_xticklabels(cases)
ax.set_ylabel("fraction with correct topology")
ax.set_ylim(0, 1.05)
ax.legend()
fig.savefig(OUT / "01_success_rate.png", dpi=100, bbox_inches="tight")
plt.close(fig)
print("\nFigure saved in", OUT)