from pathlib import Path
import numpy as np
import nibabel as nib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import ndimage as ndi
from skimage.filters import threshold_otsu

ROOT = Path(__file__).resolve().parents[2]
SCAN = ROOT / "ADHD200_BIDS/Brown/sub-0026001/ses-1/anat/sub-0026001_ses-1_run-1_T1w.nii.gz"
OUT = ROOT / "reports" / "lab02"
OUT.mkdir(parents=True, exist_ok=True)

# ---------- load the scan ----------
img = nib.load(SCAN)
data = img.get_fdata(dtype=np.float32)
voxel = float(img.header.get_zooms()[0])          # 1.0 mm for this scan
cz = data.shape[2] // 2                            # middle axial slice

# ---------- binary mask (same as Lab 01) ----------
t = threshold_otsu(data)
labels, n = ndi.label(data > t)
sizes = ndi.sum(data > t, labels, range(1, n + 1))
X = labels == (1 + int(np.argmax(sizes)))          # largest component


# ---------- structuring elements ----------
def ball(r):
    g = np.arange(-r, r + 1)
    z, y, x = np.meshgrid(g, g, g, indexing="ij")
    return (x**2 + y**2 + z**2) <= r * r


def disk(r):
    g = np.arange(-r, r + 1)
    y, x = np.meshgrid(g, g, indexing="ij")
    return (x**2 + y**2) <= r * r


B3 = ball(2)
B2 = disk(2)

# =====================================================================
# PART A: border test for closing
# =====================================================================
print("=== PART A: border test ===")


def closing(mask, b):
    return ndi.binary_erosion(ndi.binary_dilation(mask, structure=b), structure=b)


closed = closing(X, B3)
print("voxels of X lost by closing, no padding  :", int(np.sum(X & ~closed)))

pad = 3                                            # pad must be >= ball radius (2)
Xp = np.pad(X, pad)                                # add 3 voxels of background on every side
closed_p = closing(Xp, B3)[pad:-pad, pad:-pad, pad:-pad]   # close, then crop back
print("voxels of X lost by closing, with padding:", int(np.sum(X & ~closed_p)))
print("X inside closing (padded)? ->", bool(np.all(X <= closed_p)))

# =====================================================================
# PART B: grayscale operators (flat structuring element)
# =====================================================================
print("\n=== PART B: grayscale operators ===")
ero = ndi.grey_erosion(data, footprint=B3)
dil = ndi.grey_dilation(data, footprint=B3)
opn = ndi.grey_opening(data, footprint=B3)
cls = ndi.grey_closing(data, footprint=B3)
gradient = dil - ero                                # morphological gradient (slide 39-41)
tophat = data - opn                                 # top-hat (slide 42)
black_tophat = cls - data                           # conjugate top-hat (slide 42)

print("erosion <= f <= dilation :", bool(np.all(ero <= data) and np.all(data <= dil)))
print("opening <= f <= closing  :", bool(np.all(opn <= data) and np.all(data <= cls)))
print("opening idempotent       :", bool(np.array_equal(ndi.grey_opening(opn, footprint=B3), opn)))
print("closing idempotent       :", bool(np.array_equal(ndi.grey_closing(cls, footprint=B3), cls)))
print("top-hat >= 0             :", bool(tophat.min() >= 0))
print("mean intensity: f=%.1f  erosion=%.1f  dilation=%.1f  opening=%.1f  closing=%.1f"
      % (data.mean(), ero.mean(), dil.mean(), opn.mean(), cls.mean()))

# 2D versus 3D: same slice, same radius
slice2d = data[:, :, cz]
opn2d = ndi.grey_opening(slice2d, footprint=B2)
opn3d_slice = opn[:, :, cz]
print("\n2D opening vs 3D opening on the same slice:")
print("  mean absolute difference =", round(float(np.abs(opn2d - opn3d_slice).mean()), 2))
print("  mean of (2D - 3D)        =", round(float((opn2d - opn3d_slice).mean()), 2))

# figure 1: operators on the middle axial slice (from the 3D results)
vmax = float(np.percentile(data, 99.5))
panels = [("original", data), ("erosion", ero), ("dilation", dil), ("opening", opn),
          ("closing", cls), ("gradient", gradient), ("top-hat", tophat),
          ("black top-hat", black_tophat)]
fig, ax = plt.subplots(2, 4, figsize=(18, 10))
for a, (name, vol) in zip(ax.ravel(), panels):
    a.imshow(np.rot90(vol[:, :, cz]), cmap="gray", vmin=0, vmax=vmax)
    a.set_title(name)
    a.axis("off")
fig.savefig(OUT / "01_grayscale_operators.png", dpi=100, bbox_inches="tight")
plt.close(fig)

# figure 2: top-hat with sizes 3, 5, 7 (like slide 43), in 2D
fig, ax = plt.subplots(1, 4, figsize=(18, 5))
ax[0].imshow(np.rot90(slice2d), cmap="gray", vmin=0, vmax=vmax)
ax[0].set_title("original")
for a, s in zip(ax[1:], [3, 5, 7]):
    th = ndi.white_tophat(slice2d, size=s)
    a.imshow(np.rot90(th), cmap="gray", vmin=0, vmax=vmax / 3)
    a.set_title("top-hat, size %d" % s)
for a in ax:
    a.axis("off")
fig.savefig(OUT / "02_tophat_sizes.png", dpi=100, bbox_inches="tight")
plt.close(fig)

# =====================================================================
# PART C: granulometry preview (opening with growing balls)
# =====================================================================
print("\n=== PART C: granulometry preview ===")
# Additional method (not in the course): the Euclidean distance transform.
# Erosion by a ball of radius r  = keep voxels farther than r from the background.
# Dilation by a ball of radius r = keep voxels within r of the eroded set.
# This gives the exact opening by a ball, much faster than a big footprint.
dist_to_background = ndi.distance_transform_edt(X, sampling=voxel)
total = float(X.sum())

radii = [1, 2, 3, 4, 5, 6, 8, 10]                   # in mm
remaining = []
for r in radii:
    eroded = dist_to_background > r
    dist_to_eroded = ndi.distance_transform_edt(~eroded, sampling=voxel)
    opened = dist_to_eroded <= r
    remaining.append(opened.sum() / total)

print("radius (mm)   volume left after opening   removed at this step")
previous = 1.0
for r, v in zip(radii, remaining):
    print("%8d      %16.3f      %16.3f" % (r, v, previous - v))
    previous = v

fig, ax = plt.subplots(figsize=(6, 4))
ax.plot([0] + radii, [1.0] + remaining, "o-")
ax.set_xlabel("ball radius (mm)")
ax.set_ylabel("fraction of mask kept")
ax.set_title("granulometry of the head mask")
fig.savefig(OUT / "03_granulometry.png", dpi=100, bbox_inches="tight")
plt.close(fig)

print("\nFigures saved in", OUT)