import subprocess

cmd = [
    "wsl", "bash", "-c",
    "export FREESURFER_HOME=/usr/local/freesurfer/8.2.0 && "
    "source /usr/local/freesurfer/8.2.0/SetUpFreeSurfer.sh && "
    "recon-all -version"
]
result = subprocess.run(cmd, capture_output=True, text=True)
print(result.stdout)
print(result.stderr)