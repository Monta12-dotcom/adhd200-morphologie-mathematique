#!/usr/bin/env python
"""
analysis.py - Classification / regression on morphological features (ADHD-200)
================================================================================
Implements the corrected design:
  * per-site z-scoring of features (label-free site harmonisation)
  * residualisation on ICV, age, sex INSIDE every CV fold (no leakage)
  * Boruta all-relevant feature selection INSIDE every fold + random forest
  * tasks: ADHD vs control, ADHD-C vs ADHD-I, and dimensional symptom scores
  * repeated 10-fold CV  AND  leave-one-site-out (main, honest result)
  * AUC, balanced accuracy, Cohen's d, correlation of predictions with age
  * option to exclude medicated patients
  * optional permutation test on Boruta selection frequency (+ Holm correction)

Install:  pip install numpy pandas scipy scikit-learn "boruta>=0.4" statsmodels

Example:
  python analysis.py --features features.csv --pheno adhd200_pheno.csv --out_dir results
  python analysis.py ... --exclude_medicated --naive_values 0 --med_col "Med Status"
  python analysis.py ... --n_perm 100          # slow: significance of selected features
"""
import argparse
import json
import os
import warnings

import numpy as np
import pandas as pd
from boruta import BorutaPy
from scipy.stats import binom, pearsonr
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.metrics import balanced_accuracy_score, roc_auc_score
from sklearn.model_selection import KFold, LeaveOneGroupOut, StratifiedKFold
from sklearn.pipeline import Pipeline
from statsmodels.stats.multitest import multipletests

warnings.filterwarnings("ignore")
COV = ["ICV", "age", "sex"]          # covariates regressed out inside each fold
N_COV = len(COV)


# =========================================================================== transformers
class Residualizer(BaseEstimator, TransformerMixin):
    """Last n_cov columns = covariates. Returns features minus their linear
    prediction from the covariates. Fitted on the TRAIN fold only."""
    def __init__(self, n_cov=3):
        self.n_cov = n_cov

    def fit(self, X, y=None):
        self.lr_ = LinearRegression().fit(X[:, -self.n_cov:], X[:, :-self.n_cov])
        return self

    def transform(self, X):
        return X[:, :-self.n_cov] - self.lr_.predict(X[:, -self.n_cov:])


class BorutaSelector(BaseEstimator, TransformerMixin):
    """All-relevant selection (Boruta). Falls back to the best-ranked features if
    nothing is confirmed, so the pipeline never crashes."""
    def __init__(self, regression=False, max_iter=50, alpha=0.05, random_state=0, min_features=5):
        self.regression = regression
        self.max_iter = max_iter
        self.alpha = alpha
        self.random_state = random_state
        self.min_features = min_features

    def fit(self, X, y):
        if self.regression:
            est = RandomForestRegressor(n_jobs=-1, max_depth=5, random_state=self.random_state)
        else:
            est = RandomForestClassifier(n_jobs=-1, max_depth=5, class_weight="balanced",
                                         random_state=self.random_state)
        b = BorutaPy(est, n_estimators="auto", perc=100, alpha=self.alpha,
                     max_iter=self.max_iter, random_state=self.random_state)
        b.fit(np.asarray(X), np.asarray(y))
        sup = b.support_.copy()
        if sup.sum() == 0:
            sup = b.support_weak_.copy()
        if sup.sum() == 0:
            sup = np.zeros(X.shape[1], bool)
            sup[np.argsort(b.ranking_)[: self.min_features]] = True
        self.support_ = sup
        return self

    def transform(self, X):
        return np.asarray(X)[:, self.support_]


def make_pipe(regression, seed, boruta_iter, n_trees):
    if regression:
        rf = RandomForestRegressor(n_estimators=n_trees, min_samples_leaf=3, n_jobs=-1, random_state=seed)
    else:
        rf = RandomForestClassifier(n_estimators=n_trees, min_samples_leaf=3, n_jobs=-1,
                                    class_weight="balanced", random_state=seed)
    return Pipeline([
        ("imp", SimpleImputer(strategy="median", keep_empty_features=True)),
        ("res", Residualizer(N_COV)),
        ("select", BorutaSelector(regression, boruta_iter, random_state=seed)),
        ("rf", rf),
    ])


# =========================================================================== data
def load_data(a):
    F = pd.read_csv(a.features)
    if "error" in F.columns:
        F = F[F["error"].isna()].drop(columns="error")
    F["sub_id"] = pd.to_numeric(F["sub_id"], errors="coerce")

    P = pd.read_csv(a.pheno, sep=None, engine="python")
    ren = {a.id_col: "sub_id", a.site_col: "site", a.age_col: "age", a.sex_col: "sex", a.dx_col: "dx"}
    if a.med_col:
        ren[a.med_col] = "med"
    P = P.rename(columns=ren)
    num = ["sub_id", "age", "sex", "dx"] + (["med"] if a.med_col else []) + \
          [c for c in (a.score_hyper, a.score_inatt, a.score_index) if c in P.columns]
    for c in num:
        P[c] = pd.to_numeric(P[c], errors="coerce")
        P[c] = P[c].mask(P[c] <= -900)             # -999 = missing in ADHD-200
    P["site"] = P["site"].astype(str)

    df = F.merge(P, on="sub_id", how="inner").dropna(subset=["age", "sex", "dx", "ICV"])
    feats = [c for c in F.columns if c not in ("sub_id", "ICV")]
    feats = [c for c in feats if df[c].isna().mean() < 0.2 and df[c].std() > 0]

    # keep sites with enough subjects, then per-site z-scoring of features (label free)
    vc = df["site"].value_counts()
    df = df[df["site"].isin(vc[vc >= a.min_site].index)].copy()
    if a.site_norm:
        g = df.groupby("site")[feats]
        df[feats] = (df[feats] - g.transform("mean")) / (g.transform("std") + 1e-9)
    print(f"{len(df)} subjects, {len(feats)} features, sites: {df['site'].value_counts().to_dict()}")
    return df, feats


def get_task(df, task, a):
    d = df
    if a.exclude_medicated:
        if "med" not in d.columns:
            raise SystemExit("--exclude_medicated needs --med_col")
        naive = [float(v) for v in a.naive_values.split(",")]
        d = d[(d["dx"] == 0) | d["med"].isin(naive)]
    if task == "adhd_vs_control":
        d = d[d["dx"].isin([0, 1, 2, 3])]
        y = (d["dx"] > 0).astype(int).values
    elif task == "subtype":                      # 1 = combined, 0 = inattentive
        d = d[d["dx"].isin([1, 3])]
        y = (d["dx"] == 1).astype(int).values
    else:
        col = {"reg_hyper": a.score_hyper, "reg_inatt": a.score_inatt, "reg_index": a.score_index}[task]
        d = d[d[col].notna()]
        y = d.groupby("site")[col].transform(lambda s: (s - s.mean()) / (s.std() + 1e-9)).values
    return d, y


# =========================================================================== CV engine
def make_splits(y, groups, mode, n_rep, n_splits, regression, seed):
    idx = np.arange(len(y))
    if mode == "loso":
        return [list(LeaveOneGroupOut().split(idx, y, groups))]
    out = []
    for r in range(n_rep):
        cv = KFold(n_splits, shuffle=True, random_state=seed + r) if regression \
            else StratifiedKFold(n_splits, shuffle=True, random_state=seed + r)
        out.append(list(cv.split(idx, y)))
    return out


def cv_run(X, y, reps, regression, a, seed=0):
    n, n_feat = len(y), X.shape[1] - N_COV
    oof = np.full((len(reps), n), np.nan)
    sel, n_it = np.zeros(n_feat), 0
    for ri, splits in enumerate(reps):
        for tr, te in splits:
            pipe = make_pipe(regression, seed + ri, a.boruta_iter, a.n_trees)
            pipe.fit(X[tr], y[tr])
            oof[ri, te] = pipe.predict(X[te]) if regression else pipe.predict_proba(X[te])[:, 1]
            sel[pipe.named_steps["select"].support_] += 1
            n_it += 1
    return oof, sel, n_it


def cohens_d(a, b):
    sp = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / (len(a) + len(b) - 2))
    return float((a.mean() - b.mean()) / (sp + 1e-12))


def evaluate(y, oof, age, site, regression):
    rows = []
    for p in oof:
        ok = ~np.isnan(p)
        if regression:
            rows.append({"r": pearsonr(p[ok], y[ok])[0], "r_with_age": pearsonr(p[ok], age[ok])[0]})
        else:
            rows.append({"auc": roc_auc_score(y[ok], p[ok]),
                         "bal_acc": balanced_accuracy_score(y[ok], p[ok] > 0.5),
                         "cohen_d": cohens_d(p[ok][y[ok] == 1], p[ok][y[ok] == 0]),
                         "r_pred_vs_age": pearsonr(p[ok], age[ok])[0]})
    m = pd.DataFrame(rows)
    out = {k: [round(float(m[k].mean()), 3), round(float(m[k].std(ddof=0)), 3)] for k in m}
    per_site = {}                                  # first repeat, per site
    p = oof[0]
    for s in np.unique(site):
        k = (site == s) & ~np.isnan(p)
        if k.sum() < 15:
            continue
        if regression:
            per_site[s] = round(float(pearsonr(p[k], y[k])[0]), 3)
        elif min((y[k] == 1).sum(), (y[k] == 0).sum()) >= 5:
            per_site[s] = round(float(roc_auc_score(y[k], p[k])), 3)
    out["per_site"] = per_site
    return out


def selection_table(names, sel, n_it, a, X, y, regression, mode):
    tab = pd.DataFrame({"feature": names, "sel_freq": sel / max(n_it, 1)})
    if a.n_perm > 0 and mode == "kfold":
        rng = np.random.default_rng(a.seed)
        pf = np.zeros(len(names))
        for _ in range(a.n_perm):
            yp = rng.permutation(y)
            reps = make_splits(yp, None, "kfold", 1, a.n_splits, regression, int(rng.integers(1e6)))
            _, s, it = cv_run(X, yp, reps, regression, a)
            pf += s / it
        p0 = np.clip(pf / a.n_perm, 0.5 / (a.n_perm * a.n_splits), 1)
        tab["p_binom"] = binom.sf(sel - 1, n_it, p0)
        tab["p_holm"] = multipletests(tab["p_binom"], method="holm")[1]
    return tab.sort_values("sel_freq", ascending=False)


def run_task(df, feats, task, a):
    d, y = get_task(df, task, a)
    regression = task.startswith("reg_")
    X = np.c_[d[feats].values, d[COV].values]
    site, age = d["site"].values, d["age"].values
    print(f"\n=== {task} | n={len(y)}" + ("" if regression else f" | positives={int(y.sum())}"))
    results = []
    for mode in ("loso", "kfold"):
        reps = make_splits(y, site, mode, a.n_repeats, a.n_splits, regression, a.seed)
        oof, sel, n_it = cv_run(X, y, reps, regression, a, a.seed)
        met = evaluate(y, oof, age, site, regression)
        tab = selection_table(feats, sel, n_it, a, X, y, regression, mode)
        tag = f"{task}_{mode}" + ("_naive" if a.exclude_medicated else "")
        tab.to_csv(os.path.join(a.out_dir, f"{tag}_features.csv"), index=False)
        res = {"task": task, "mode": mode, "n": int(len(y)), "medicated_excluded": a.exclude_medicated, **met}
        json.dump(res, open(os.path.join(a.out_dir, f"{tag}.json"), "w"), indent=2)
        print(mode.upper(), {k: v for k, v in met.items() if k != "per_site"})
        print("   per-site:", met["per_site"])
        print("   top features:", ", ".join(tab["feature"].head(5)))
        results.append(res)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--features", required=True)
    ap.add_argument("--pheno", required=True)
    ap.add_argument("--out_dir", default="results")
    ap.add_argument("--id_col", default="ScanDir ID")
    ap.add_argument("--site_col", default="Site")
    ap.add_argument("--age_col", default="Age")
    ap.add_argument("--sex_col", default="Gender")
    ap.add_argument("--dx_col", default="DX")
    ap.add_argument("--med_col", default="Med Status")
    ap.add_argument("--naive_values", default="0", help="values of med_col meaning medication-naive (check the data dictionary!)")
    ap.add_argument("--score_hyper", default="Hyper/Impulsive")
    ap.add_argument("--score_inatt", default="Inattentive")
    ap.add_argument("--score_index", default="ADHD Index")
    ap.add_argument("--tasks", default="adhd_vs_control,subtype,reg_hyper,reg_inatt")
    ap.add_argument("--exclude_medicated", action="store_true")
    ap.add_argument("--no_site_norm", dest="site_norm", action="store_false")
    ap.add_argument("--min_site", type=int, default=20)
    ap.add_argument("--n_splits", type=int, default=10)
    ap.add_argument("--n_repeats", type=int, default=3)
    ap.add_argument("--boruta_iter", type=int, default=50)
    ap.add_argument("--n_trees", type=int, default=300)
    ap.add_argument("--n_perm", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)

    df, feats = load_data(a)
    allres = []
    for t in a.tasks.split(","):
        allres += run_task(df, feats, t.strip(), a)
    rows = []
    for r in allres:
        rows.append({"task": r["task"], "mode": r["mode"], "n": r["n"],
                     **{k: v[0] for k, v in r.items() if isinstance(v, list)}})
    summ = pd.DataFrame(rows)
    summ.to_csv(os.path.join(a.out_dir, "summary" + ("_naive" if a.exclude_medicated else "") + ".csv"), index=False)
    print("\n", summ.to_string(index=False))


if __name__ == "__main__":
    main()