#!/usr/bin/env python
"""
features.py - Morphological feature extraction from T1w brain images (ADHD-200)
=================================================================================
Uses ONLY course operators (scipy.ndimage / scikit-image): thresholding, opening,
closing, ASF, reconstruction (geodesic), distance transform, granulometry,
anti-granulometry, top-hat / bottom-hat, morphological gradient, skeleton,
Euler number, ultimate erosion, geodesic diameter, connected components.

INPUT : skull-stripped T1w images registered to MNI (ADHD-200 "Athena" release),
        one NIfTI per subject. Subject id is read from the file path (regex).
OUTPUT: features.csv  (one row per subject; 'ICV' column = brain-mask volume, mm3)

Install:  pip install numpy scipy scikit-image nibabel pandas joblib matplotlib

Example:
  python features.py --data_dir /data/adhd200 --glob "**/*.nii.gz" \
         --out features.csv --grid 3 --n_jobs 4 --qc_dir qc --qc_n 20
  # with an atlas (label image in the SAME space/grid as the T1 images):
  python features.py ... --atlas HarvardOxford-cort-maxprob-thr25-2mm.nii.gz
"""
import argparse
import glob
import os
import re

import numpy as np
import pandas as pd
import nibabel as nib
from joblib import Parallel, delayed
from scipy import ndimage as ndi
from scipy.stats import kurtosis, skew
from skimage.filters import threshold_multiotsu, threshold_otsu
from skimage.measure import euler_number
from skimage.morphology import ball, skeletonize

RADII = [1, 2, 3, 4, 5, 6]            # structuring-element radii (voxels) for granulometry
S26 = np.ones((3, 3, 3), bool)         # 26-connectivity (8-connexity in 3D)
S6 = ndi.generate_binary_structure(3, 1)  # 6-connectivity (4-connexity in 3D)


def B(r):
    """Ball structuring element of radius r (boolean)."""
    return ball(r).astype(bool)


# --------------------------------------------------------------------------- helpers
def largest_cc(mask):
    """Connected-component labeling, keep the biggest component."""
    lab, n = ndi.label(mask, S26)
    if n == 0:
        return mask
    sizes = np.bincount(lab.ravel())
    sizes[0] = 0
    return lab == sizes.argmax()


def remove_small(mask, min_size=30):
    """Remove connected components smaller than min_size voxels."""
    lab, n = ndi.label(mask, S26)
    if n == 0:
        return mask
    sizes = np.bincount(lab.ravel())
    keep = sizes >= min_size
    keep[0] = False
    return keep[lab]


def asf(mask, n=2):
    """Alternating sequential filter: opening then closing with growing balls."""
    m = mask
    for r in range(1, n + 1):
        m = ndi.binary_opening(m, B(r))
        m = ndi.binary_closing(m, B(r))
    return m


def stats(v, name):
    keys = ("mean", "std", "skew", "kurt", "p90")
    if v.size < 5:
        return {f"{name}_{k}": np.nan for k in keys}
    return {f"{name}_mean": float(v.mean()), f"{name}_std": float(v.std()),
            f"{name}_skew": float(skew(v)), f"{name}_kurt": float(kurtosis(v)),
            f"{name}_p90": float(np.percentile(v, 90))}


def mean_or_nan(v):
    return float(v.mean()) if v.size else np.nan


# --------------------------------------------------------------------------- segmentation
def brain_mask(img, skull_stripped=True):
    if skull_stripped:
        m = img > 0
    else:  # rough fallback; check visually!
        m = img > 0.6 * threshold_otsu(img)
        m = ndi.binary_opening(m, B(3))        # cut thin links (skull, neck)
    m = largest_cc(m)                          # labeling
    return ndi.binary_fill_holes(m)            # hole filling


def flatten_bias(img, mask, sigma=8):
    """Simple intensity-inhomogeneity correction (divide by smoothed image)."""
    num = ndi.gaussian_filter(img * mask, sigma)
    den = ndi.gaussian_filter(mask.astype(np.float32), sigma) + 1e-6
    return (img / (num / den + 1e-6)) * mask


# --------------------------------------------------------------------------- measures
def gran_curve(opened_list, base, reg):
    """Fraction of `base` surviving each opening, restricted to region `reg`."""
    v0 = (base & reg).sum()
    if v0 == 0:
        return np.full(len(opened_list), np.nan)
    return np.array([(o & reg).sum() / v0 for o in opened_list])


def gran_meansize(curve):
    if np.isnan(curve).any():
        return np.nan
    spec = -np.diff(np.r_[1.0, curve])          # granulometric spectrum
    return float((spec * np.array(RADII)).sum() + curve[-1] * (RADII[-1] + 1))


def ultimate_erosion(mask, vox):
    """Regional maxima of the distance map = ultimate erosion markers."""
    if mask.sum() == 0:
        return 0, np.nan
    d = ndi.distance_transform_edt(mask, sampling=vox)
    rm = (d == ndi.maximum_filter(d, size=3)) & mask
    _, n = ndi.label(rm, S26)
    return int(n), float(d.max())


def geodesic_diameter(mask):
    """Geodesic diameter (8-connexity steps) by two geodesic-dilation sweeps."""
    if mask.sum() == 0:
        return np.nan
    mask = largest_cc(mask)
    sl = ndi.find_objects(mask.astype(np.uint8))[0]
    mask = mask[sl]

    def sweep(seed):
        reached, last, steps = seed, seed, 0
        while True:
            new = ndi.binary_dilation(reached, structure=S26, mask=mask)
            added = new & ~reached
            if not added.any():
                return steps, last
            reached, last, steps = new, added, steps + 1

    seed = np.zeros_like(mask)
    seed[tuple(np.argwhere(mask)[0])] = True
    _, last = sweep(seed)
    seed2 = np.zeros_like(mask)
    seed2[tuple(np.argwhere(last)[0])] = True
    d, _ = sweep(seed2)
    return float(d)


def skeleton_stats(mask):
    if mask.sum() == 0:
        return np.nan, np.nan
    sk = skeletonize(mask).astype(bool)
    nb = ndi.convolve(sk.astype(np.uint8), np.ones((3, 3, 3), np.uint8), mode="constant") - 1
    return float(sk.sum()), float((sk & (nb >= 3)).sum())


# --------------------------------------------------------------------------- main per-subject
def block_mean(img, f):
    """Downsample by an integer factor f using block averaging."""
    if f <= 1:
        return img
    n = [s // f for s in img.shape]
    img = img[:n[0] * f, :n[1] * f, :n[2] * f]
    return img.reshape(n[0], f, n[1], f, n[2], f).mean(axis=(1, 3, 5)).astype(np.float32)


def process_subject(path, sid, atlas_path, grid, skull_stripped, qc_dir=None, down=2):
    nii = nib.load(path)
    img = np.asarray(nii.get_fdata(dtype=np.float32))
    if img.ndim == 4:
        img = img[..., 0]
    vox = tuple(float(z) * down for z in nii.header.get_zooms()[:3])
    img = block_mean(img, down)
    vvox = float(np.prod(vox))

    # ---- 1. brain mask, bias correction, tissue classes
    mask = brain_mask(img, skull_stripped)
    img = flatten_bias(img, mask)
    thr = threshold_multiotsu(img[mask], classes=3)
    lab = np.digitize(img, thr)                       # 0 CSF, 1 GM, 2 WM
    inner = ndi.binary_erosion(mask, B(1))            # avoid dark edge voxels counted as CSF

    wm = remove_small(asf((lab == 2) & mask))
    gm = remove_small(asf((lab == 1) & mask)) & ~wm
    csf = remove_small((lab == 0) & inner)
    tissue = gm | wm

    # ---- 2. ventricles by geodesic reconstruction from a central marker
    csf_core = ndi.binary_opening(csf, B(1))
    cm = ndi.center_of_mass(mask)
    zz, yy, xx = np.ogrid[:mask.shape[0], :mask.shape[1], :mask.shape[2]]
    sphere = (((zz - cm[0]) * vox[0]) ** 2 + ((yy - cm[1]) * vox[1]) ** 2
              + ((xx - cm[2]) * vox[2]) ** 2) < 20.0 ** 2          # 20 mm radius
    marker = csf_core & sphere
    vent = ndi.binary_propagation(marker, structure=S6, mask=csf_core) if marker.any() \
        else np.zeros_like(mask)
    sulc = csf & ~vent                                 # sulcal / extra-axial CSF

    # ---- 3. maps used by the features
    wm_med = np.median(img[wm]) if wm.any() else 1.0
    imgm = (img / wm_med) * mask
    edt_gm = ndi.distance_transform_edt(gm, sampling=vox)       # thickness proxy (half-thickness)
    edt_wm = ndi.distance_transform_edt(wm, sampling=vox)
    edt_sulc = ndi.distance_transform_edt(sulc, sampling=vox)   # sulcal width proxy
    bot = ndi.grey_closing(imgm, footprint=B(2)) - imgm         # bottom-hat (dark narrow = sulci)
    top = imgm - ndi.grey_opening(imgm, footprint=B(2))         # top-hat (small bright details)
    grad = ndi.grey_dilation(imgm, footprint=B(1)) - ndi.grey_erosion(imgm, footprint=B(1))
    band = ndi.binary_dilation(gm, B(1)) & ndi.binary_dilation(wm, B(1))   # GM/WM border band
    gm_open = [ndi.binary_opening(gm, B(r)) for r in RADII]            # granulometry
    wm_open = [ndi.binary_opening(wm, B(r)) for r in RADII]
    tis_gain = [ndi.binary_closing(tissue, B(r)) & ~tissue for r in RADII]  # anti-granulometry

    def region_feats(p, reg):
        o = {}
        nb = max(int((reg & mask).sum()), 1)
        o[f"{p}_gm_frac"] = (gm & reg).sum() / nb
        o[f"{p}_wm_frac"] = (wm & reg).sum() / nb
        o[f"{p}_sulc_frac"] = (sulc & reg).sum() / nb
        o[f"{p}_vent_frac"] = (vent & reg).sum() / nb
        o.update(stats(edt_gm[gm & reg], f"{p}_gmthick"))
        o[f"{p}_wmthick_mean"] = mean_or_nan(edt_wm[wm & reg])
        o[f"{p}_sulcwidth_mean"] = mean_or_nan(edt_sulc[sulc & reg])
        o[f"{p}_bothat_mean"] = mean_or_nan(bot[reg & mask])
        o[f"{p}_tophat_mean"] = mean_or_nan(top[reg & mask])
        o[f"{p}_grad_mean"] = mean_or_nan(grad[band & reg])
        c = gran_curve(gm_open, gm, reg)
        o[f"{p}_gm_gran_meansize"] = gran_meansize(c)
        o[f"{p}_gm_gran_r2"], o[f"{p}_gm_gran_r4"] = c[1], c[3]
        tv = max(int((tissue & reg).sum()), 1)
        for r in (1, 2, 3):
            o[f"{p}_antigran_r{r}"] = (tis_gain[r - 1] & reg).sum() / tv
        return o

    f = {"sub_id": sid, "ICV": float(mask.sum() * vvox)}

    # ---- 4. global features
    f.update(region_feats("global", mask))
    gc, wc = gran_curve(gm_open, gm, mask), gran_curve(wm_open, wm, mask)
    for i, r in enumerate(RADII):
        f[f"global_gm_gran_curve_r{r}"] = gc[i]
        f[f"global_wm_gran_curve_r{r}"] = wc[i]
        f[f"global_antigran_r{r}"] = (tis_gain[i].sum() / max(tissue.sum(), 1))
    f["global_wm_gran_meansize"] = gran_meansize(wc)
    f["global_bothat_energy"] = float((bot[mask] ** 2).sum() / max(mask.sum(), 1))
    f["global_grad_std"] = float(grad[band].std()) if band.any() else np.nan
    for nm, m in (("gm", gm), ("wm", wm), ("vent", vent)):
        f[f"global_{nm}_euler"] = int(euler_number(m, connectivity=1)) if m.any() else np.nan
        f[f"global_{nm}_ncc"] = int(ndi.label(m, S26)[1])
    sk_len, sk_bp = skeleton_stats(wm)
    f["global_wm_skel_len_norm"] = sk_len / max(wm.sum(), 1)
    f["global_wm_skel_branch_norm"] = sk_bp / max(wm.sum(), 1)
    n_ue, max_d = ultimate_erosion(vent, vox)
    f["global_vent_ue_n"], f["global_vent_maxdist_mm"] = n_ue, max_d
    f["global_vent_geo_diam"] = geodesic_diameter(vent)
    f["global_vent_volume_mm3"] = float(vent.sum() * vvox)

    # ---- 5. regional features (atlas labels or a grid of blocks)
    regions = {}
    if atlas_path:
        atlas = np.asarray(nib.load(atlas_path).dataobj).astype(int)
        atlas = atlas[:mask.shape[0] * down:down, :mask.shape[1] * down:down, :mask.shape[2] * down:down]
        if atlas.shape != mask.shape:
            raise ValueError(f"atlas shape {atlas.shape} != image shape {mask.shape}")
        for l in np.unique(atlas[atlas > 0]):
            regions[f"atl{l}"] = (atlas == l) & mask
    else:
        idx = np.argwhere(mask)
        lo, hi = idx.min(0), idx.max(0) + 1
        edges = [np.linspace(lo[d], hi[d], grid + 1).astype(int) for d in range(3)]
        for i in range(grid):
            for j in range(grid):
                for k in range(grid):
                    r = np.zeros_like(mask)
                    r[edges[0][i]:edges[0][i + 1], edges[1][j]:edges[1][j + 1],
                      edges[2][k]:edges[2][k + 1]] = True
                    regions[f"g{i}{j}{k}"] = r & mask
    for name, reg in regions.items():
        if reg.sum() >= 200:
            f.update(region_feats(name, reg))

    # ---- 6. QC image
    if qc_dir:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        os.makedirs(qc_dir, exist_ok=True)
        z = int(cm[2])
        seg = np.zeros(mask.shape, np.uint8)
        seg[sulc] = 1; seg[gm] = 2; seg[wm] = 3; seg[vent] = 4
        fig, ax = plt.subplots(1, 2, figsize=(8, 4))
        ax[0].imshow(img[:, :, z].T, cmap="gray", origin="lower"); ax[0].set_title("T1")
        ax[1].imshow(seg[:, :, z].T, cmap="nipy_spectral", origin="lower", vmin=0, vmax=4)
        ax[1].set_title("sulcCSF=1 GM=2 WM=3 vent=4")
        for a in ax:
            a.axis("off")
        fig.savefig(os.path.join(qc_dir, f"{sid}.png"), dpi=80, bbox_inches="tight")
        plt.close(fig)
    return f


def safe(path, sid, *a):
    try:
        return process_subject(path, sid, *a)
    except Exception as e:  # keep going, record the error
        return {"sub_id": sid, "error": f"{type(e).__name__}: {e}"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_dir", required=True)
    ap.add_argument("--glob", default="**/*.nii*")
    ap.add_argument("--id_regex", default=r"(\d{7})", help="regex with 1 group applied to the file path")
    ap.add_argument("--out", default="features.csv")
    ap.add_argument("--atlas", default=None)
    ap.add_argument("--grid", type=int, default=3, help="blocks per axis if no atlas")
    ap.add_argument("--not_skull_stripped", action="store_true")
    ap.add_argument("--n_jobs", type=int, default=2)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--qc_dir", default=None)
    ap.add_argument("--qc_n", type=int, default=20)
    ap.add_argument("--downsample", type=int, default=2, help="integer factor (2 = 2 mm voxels, ~8x faster)")
    a = ap.parse_args()

    files = sorted(glob.glob(os.path.join(a.data_dir, a.glob), recursive=True))
    jobs = []
    for p in files:
        m = re.search(a.id_regex, p)
        if m:
            jobs.append((p, m.group(1)))
    if a.limit:
        jobs = jobs[:a.limit]
    print(f"{len(jobs)} images found")
    import json, time
    part = a.out + ".partial.jsonl"
    done = {}
    if os.path.exists(part):
        for line in open(part):
            try:
                r = json.loads(line)
                if "error" not in r:
                    done[str(r["sub_id"])] = r
            except Exception:
                pass
        print(f"resuming: {len(done)} subjects already done")
    todo = [(p, sid, k) for k, (p, sid) in enumerate(jobs) if sid not in done]
    t0 = time.time()
    out = open(part, "a")
    gen = Parallel(n_jobs=a.n_jobs, return_as="generator")(
        delayed(safe)(p, sid, a.atlas, a.grid, not a.not_skull_stripped,
                      a.qc_dir if k < a.qc_n else None, a.downsample)
        for p, sid, k in todo)
    for n, r in enumerate(gen, 1):
        out.write(json.dumps(r, default=float) + "\n")
        out.flush()
        if "error" in r:
            print(f"  [{n}/{len(todo)}] {r['sub_id']} FAILED: {r['error']}", flush=True)
        else:
            el = time.time() - t0
            print(f"  [{n}/{len(todo)}] {r['sub_id']} ok | {el/60:.1f} min elapsed | "
                  f"ETA {el/n*(len(todo)-n)/60:.0f} min", flush=True)
    out.close()
    rows = [json.loads(l) for l in open(part)]
    df = pd.DataFrame(rows).drop_duplicates("sub_id", keep="last")
    df.to_csv(a.out, index=False)
    if "error" in df:
        bad = df[df["error"].notna()]
        print(f"{len(bad)} failures:\n", bad[["sub_id", "error"]].head(20).to_string())
    print("saved", a.out, df.shape)


if __name__ == "__main__":
    main()